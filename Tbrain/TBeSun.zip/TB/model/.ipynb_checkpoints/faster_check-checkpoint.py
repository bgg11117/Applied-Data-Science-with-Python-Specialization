import pandas as pd
import numpy as np
import operator

import matplotlib.pyplot as plt
import seaborn as sns

import gc, os, pickle, random, time, cmath, re
import geopy
from collections import Counter, defaultdict

from contextlib import contextmanager
import shap

from datetime import datetime
# import librosa
from sklearn.metrics import roc_auc_score
from sklearn.metrics import mean_absolute_error, median_absolute_error, mean_squared_error,r2_score
from sklearn.model_selection import StratifiedShuffleSplit, KFold
from sklearn.model_selection import cross_val_score,cross_val_predict
from sklearn.mixture import BayesianGaussianMixture
from sklearn.linear_model import BayesianRidge
from sklearn.neighbors import KNeighborsClassifier 
from sklearn.cluster import KMeans

from lightgbm import LGBMClassifier, LGBMRegressor
from category_encoders import *

import warnings
warnings.simplefilter(action='ignore', category=FutureWarning)
warnings.filterwarnings('ignore')

def display_shapley_values(feat_importance):
    best_features = feat_importance[["feature", "shap_values"]].groupby("feature")["shap_values"].agg(['mean', 'std']) \
                                                               .sort_values(by="mean", ascending=False).head(40).reset_index()
    best_features.columns = ["feature", "mean shapley values", "err"]
    plt.figure(figsize=(8, 10))
    sns.barplot(x="mean shapley values", y="feature", xerr=best_features['err'], data=best_features)
    plt.title('LightGBM shapley values (avg over folds)')
    plt.savefig('shap_{}.png'.format(dt_today.strftime("%m_%d")))
    plt.tight_layout()
    plt.show()


def display_importances(feature_importance_df_, target, dt_today):
    cols = feature_importance_df_[["feature", "importance"]].groupby("feature").mean().sort_values(by="importance", ascending=False)[:40].index
    best_features = feature_importance_df_.loc[feature_importance_df_.feature.isin(cols)]
    plt.figure(figsize=(8, 10))
    sns.barplot(x="importance", y="feature", data=best_features.sort_values(by="importance", ascending=False))
    plt.title('LightGBM Features (avg over folds)')
    plt.tight_layout()
    plt.savefig('lgbm_{}_{}.png'.format(target, dt_today.strftime("%m_%d")))
    
def fast_clf_verification(train, test, target, folds = 5, imbalanced = False):
    trn_shape = train.shape[0]
    
    train.dropna(subset=[target], inplace=True)
    test.dropna(subset=[target], inplace=True)
    
    combine = pd.concat([train, test])
    drop_list = list(combine.select_dtypes(exclude=[np.number]).columns)  + ['total_price'] + [target]
    feats = [i for i in combine.columns if i not in drop_list ]
    X = combine[feats]
    y = combine[target]
    
    if imbalanced == True:
        sss = StratifiedShuffleSplit(n_splits=folds, test_size=0.2, random_state=2019)
    else: sss = KFold(n_splits=folds, random_state=2019, shuffle=True)
        
    feature_importance_df = pd.DataFrame()
    oof_preds = np.zeros(combine.shape[0])
    
    for fold_, (train_index, test_index) in enumerate(sss.split(X, y)):
        X_train, X_test = X.iloc[train_index], X.iloc[test_index]
        y_train, y_test = y.iloc[train_index], y.iloc[test_index]
        clf = LGBMClassifier(n_estimators=50000,
                            #objective='mae',
                            learning_rate =  0.01,#0.003,
                            num_leaves=90,                
                            feature_fraction = 0.5, # sub_feature
                            bagging_fraction= 0.8)
        clf.fit(X_train, y_train, eval_set=[ (X_test, y_test )], 
                eval_metric = 'auc', verbose= False, early_stopping_rounds= 300)
        
        y_pred = clf.predict_proba(X_test, num_iteration=clf.best_iteration_)[:,1]
        print('Fold {}'.format(fold_ + 1), 'RoC-AUC: {}'.format(roc_auc_score(y_test, y_pred)))
        fold_importance_df = pd.DataFrame()
        print(len(feats), len(clf.feature_importances_))
        fold_importance_df["feature"] = feats
        fold_importance_df["importance"] = clf.feature_importances_
#         fold_importance_df["shap_values"] = abs(shap.TreeExplainer(clf).shap_values(valid_x)[:,:test_df.shape[1]]).mean(axis=0).T
        fold_importance_df["fold"] = fold_+ 1
        feature_importance_df = pd.concat([feature_importance_df, fold_importance_df], axis=0)
    dt_today = datetime.today()
    display_importances(feature_importance_df, target, dt_today)

def fast_reg_verification(train, test, target, folds = 5, normalize = True):
    trn_shape = train.shape[0]
    
    train.dropna(subset=[target], inplace=True)
    test.dropna(subset=[target], inplace=True)
    combine = pd.concat([train, test])
    
    drop_list = list(combine.select_dtypes(exclude=[np.number]).columns)  + ['total_price'] + [target]
    feats = [i for i in combine.columns if i not in drop_list ]
    X = combine[feats]
    if normalize:
        y = np.log1p(combine[target])
    else:
        y = combine[target]
        
    
    sss = KFold(n_splits=folds, random_state=2019, shuffle=True)
        
    feature_importance_df = pd.DataFrame()
    oof_preds = np.zeros(combine.shape[0])
    
    for fold_, (train_index, test_index) in enumerate(sss.split(X, y)):
        X_train, X_test = X.iloc[train_index], X.iloc[test_index]
        y_train, y_test = y.iloc[train_index], y.iloc[test_index]
        rg = LGBMRegressor(n_estimators=50000,
                            #objective='mae',
                            learning_rate =  0.01,#0.003,
                            num_leaves=90,                
                            feature_fraction = 0.5, # sub_feature
                            bagging_fraction= 0.8, # subsample)
                          )
        rg.fit(X_train, y_train, eval_set=[ (X_test, y_test )], 
                verbose= False, early_stopping_rounds= 300)
        if normalize: 
            y_pred = np.expm1(rg.predict(X_test, num_iteration=rg.best_iteration_))
        else:
            y_pred = rg.predict(X_test, num_iteration=rg.best_iteration_)
            
        print('Fold {}'.format(fold_ + 1), 'Mean AE: {}'.format(mean_absolute_error(y_test, y_pred)))
        print('Fold {}'.format(fold_ + 1), 'Median AE: {}'.format(median_absolute_error(y_test, y_pred)))
        print('Fold {}'.format(fold_ + 1), 'MSE: {}'.format(mean_squared_error(y_test, y_pred)))
        print('Fold {}'.format(fold_ + 1), 'R2: {}'.format(r2_score(y_test, y_pred)))

        fold_importance_df = pd.DataFrame()
        fold_importance_df["feature"] = feats
        fold_importance_df["importance"] = rg.feature_importances_
#         fold_importance_df["shap_values"] = abs(shap.TreeExplainer(rg).shap_values(valid_x)[:,:test_df.shape[1]]).mean(axis=0).T
        fold_importance_df["fold"] = fold_+ 1
        feature_importance_df = pd.concat([feature_importance_df, fold_importance_df], axis=0)
    dt_today = datetime.today()
    display_importances(feature_importance_df, target, dt_today)

    

def Tell_me_Why(train, target, num_fold = 12, shuffle = True, random_state = 0, num_feas = 7):
    """
    在訓練過程中，有一些Fold成績很糟糕，為什麼？
    檢視基本的統計數據，從 diff_mean / abs(diff_std)^2 
    排序去看
    PS, 請確認random state 要一樣
    """
    feature_names = list(train.select_dtypes(include=[np.number]).columns)

    X = train[feature_names ]
    y = np.log1p(target)
    sss = KFold(n_splits = num_fold, shuffle = shuffle, random_state = random_state)

    for fold_, (train_index, test_index) in enumerate(sss.split(X, y)):
        X_train, X_test = X.iloc[train_index], X.iloc[test_index]


        feature_stats = pd.DataFrame({'feature': feature_names})
        feature_stats.loc[:, 'train_mean'] = np.nanmean(X_train[feature_names].values, axis=0).round(4)
        feature_stats.loc[:, 'test_mean'] = np.nanmean(X_test[feature_names].values, axis=0).round(4)
        feature_stats.loc[:, 'train_std'] = np.nanstd(X_train[feature_names].values, axis=0).round(4)
        feature_stats.loc[:, 'test_std'] = np.nanstd(X_test[feature_names].values, axis=0).round(4)
        feature_stats.loc[:, 'train_nan'] = np.mean(np.isnan(X_train[feature_names].values), axis=0).round(3)
        feature_stats.loc[:, 'test_nan'] = np.mean(np.isnan(X_test[feature_names].values), axis=0).round(3)
        feature_stats.loc[:, 'train_test_mean_diff'] = np.abs(feature_stats['train_mean'] - feature_stats['test_mean']) / np.abs(feature_stats['train_std'] + feature_stats['test_std'])  * 2
        feature_stats.loc[:, 'train_test_nan_diff'] = np.abs(feature_stats['train_nan'] - feature_stats['test_nan'])
        feature_stats = feature_stats.sort_values(by='train_test_mean_diff', ascending=False)
        print('Fold: ', fold_+1, feature_stats[['feature', 'train_test_mean_diff']].head(num_feas),'\n')

