import pandas as pd
import numpy as np


def feature_engineer(train, test):
    """
    Before FE please do correction first
    """    
    train['floor_2_top'] = train['total_floor'] -  train['txn_floor']
    train['area_ratio'] = train['building_area']/train['land_area'] # Very Powerful
    train['XIII_diff'] = train['XIII_10000'] - train['XIII_5000']
    train['XIII_diff_4_3'] = train['XIII_10000'] - train['XIII_1000']
    train['XIII_diff_3_2'] = train['XIII_1000'] - train['XIII_500']


    test['floor_2_top'] = test['total_floor'] -  test['txn_floor']
    test['area_ratio'] = test['building_area']/test['land_area'] # Very Powerful
    test['XIII_diff'] = test['XIII_10000'] - test['XIII_5000']
    test['XIII_diff_4_3'] = test['XIII_10000'] - test['XIII_1000']
    test['XIII_diff_3_2'] = test['XIII_1000'] - test['XIII_500']
    return train, test
