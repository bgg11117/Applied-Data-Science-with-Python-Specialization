'''
__author__ = "Kueipo Huang, BGG, Albert Zheng"
__copyright__ = "Copyright 2019, The Soution for T-Brain E-Sun Bank Real Estate Prediction"
__credits__ = [Kueipo Huang", "BGG, Albert Zheng"]
__version__ = "0.0.0.0"
__maintainer__ = "Kueipo"
__email__ = "  ?????? @cathayholdings.com.tw"
__status__ = "Production"
'''

import pandas as pd
import numpy as np
from numpy.linalg import inv

import matplotlib.pyplot as plt
import seaborn as sns
sns.set()

from geopy.distance import great_circle
import gc, os, pickle, random, time, cmath
gc.enable()
import geopy
from collections import Counter, defaultdict
from functools import partial
from pathlib import Path

from contextlib import contextmanager
import multiprocessing

################# MS interpret#################
import shap
from interpret import show


from datetime import datetime
from sklearn.metrics import roc_auc_score
from sklearn.mixture import BayesianGaussianMixture
from sklearn.linear_model import BayesianRidge

from sklearn.model_selection import StratifiedShuffleSplit, KFold
from sklearn.model_selection import cross_val_score,cross_val_predict
from sklearn.neighbors import KNeighborsClassifier 
from sklearn.cluster import KMeans, DBSCAN
from lightgbm import LGBMClassifier, LGBMRegressor
from category_encoders import *

import warnings
warnings.simplefilter(action='ignore', category=FutureWarning)
warnings.filterwarnings('ignore')

##################    UtilityFunction    #################
from utils_1 import feat_nunique, feat_mean, feat_std, feat_median
from utils_1 import feat_min, feat_max, feat_var, feat_sum, feat_quantile
from score import score, hit_rate, Mape

from faster_check import fast_clf_verification, fast_reg_verification, display_importances
from crucial_plot import display_shapley_values, display_lgb_importances
from score import hit_rate, Mape, score

##################    Helper Function    ################

@contextmanager
def timer(name):
    """
    utility timer function to check how long a piece of code might take to run.
    :param name: name of the code fragment to be timed
    :yield: time taken for the code to run
    """
    t0 = time.time()
    print('[%s] in progress' % name)
    yield
    print('[%s] done in %.0f s' %(name, time.time() - t0))

    

def load_df(dataset):
    if 'train' in dataset:
        df = pd.read_csv("../data/{}.csv".format(dataset))
    elif 'test' in dataset:
        df = pd.read_csv("../data/{}.csv".format(dataset))
    elif 'submit' in dataset:
        df = pd.read_csv("../data/{}.csv".format(dataset))
    return df



def kmeans_target_encoder(train, test):
    cate = 'lonlat'
    train[cate ] = train['lon'].apply(lambda x: str((int(x*100)))) + 
                    train['lat'].apply(lambda x: str((int(x*-100))))
    test[cate ] = test['lon'].apply(lambda x: str((int(x*100)))) + 
                    test['lat'].apply(lambda x: str((int(x*-100))))

    
    X_train = train.drop(['total_price'],axis=1)
    y_train = np.log1p(train['total_price'])

    encoder = cluster_target_encoder(nclusters=3, seed=2019, njobs = -1)
    labels_train = encoder.fit_transform(X_train[cate],train['total_price'])
    labels_test = encoder.transform(test[cate])
    est = LGBMClassifier()

    est.fit(X_train.select_dtypes(include=[np.number]),labels_train)

    labels_test[np.isnan(labels_test)] = est.predict(
        test.select_dtypes(include=[np.number]))[np.isnan(labels_test)]

    ######################## Ordinal re-Label #######################
    from collections import OrderedDict
    from operator import itemgetter
    
    m_dict = {i: np.median(np.log1p(train['total_price']).values[train['labels']==i]) for i in range(clusters)}
    d = OrderedDict(sorted(m_dict.items(), key=itemgetter(1), reverse=False))
    re_map = {k: i for i, (k, _) in enumerate(d.items())}
    del d, m_dict;gc.collect()

    train['labels'] = train['labels'].map(re_map)
    test['labels'] = test['labels'].map(re_map)
    
    
    if nclusters==2:
        print('Checking the KMeans Label Performance')
        kfold = StratifiedShuffleSplit(n_splits=5, test_size=0.1, random_state=2019)
        print('KMeans Target Encoding ROC-AUC: ',cross_val_score(
                X = X_train.select_dtypes(include=[np.number]),
                y = labels_train,
                estimator = LGBMClassifier(),
                cv = kfold,
                scoring = 'roc_auc'))
    del labels_train, labels_test, X_train, y_train ;
    gc.collect()
    
    return train, test


    

def model(trn, sub, folds, save):
    print('Official Metrics Test Score: ',score(np.array([1000,1000,1000]), np.array([1300,1100,1050])))
    trn_shape = trn.shape[0]
    print('Shape Trn {} Sub {}'.format(trn.shape, sub.shape))
    feats = [f for f in trn.columns if f not in ['building_id', 'total_price','lonlat','CTV']]
    combine = pd.concat([trn[feats], sub[feats]])
    
    average = 0
    for col in feats:
        average += np.array(combine[col].rank(ascending=1))
    average = average/len(feats)
    combine['AVERAGE'] = average
    feats = [f for f in trn.columns if f not in ['building_id', 'total_price','lonlat','CTV']]

    trn = combine.iloc[:trn_shape, :]
    sub = combine.iloc[trn_shape:, :]
    
    del combine; gc.collect()
    X = trn[feats]
    y = np.log1p(target)    
    
    sss = KFold(n_splits=folds, shuffle=True, random_state=0)
    feature_importance_df = pd.DataFrame()
    oof_preds = np.zeros(trn.shape[0])
    sub_preds = np.zeros(sub.shape[0])
    
    for fold_, (train_index, test_index) in enumerate(sss.split(X, y)):
        X_train, X_test = X.iloc[train_index], X.iloc[test_index]
        y_train, y_test = y.iloc[train_index], y.iloc[test_index]
        
        clf = LGBMRegressor(n_estimators=100000,
#                             objective='fair',
                            learning_rate =  0.01,#0.003,
                            num_leaves=150,                
                            feature_fraction = 0.5, # sub_feature ([x]0.4), ([O]0.5)
                            bagging_fraction= 0.8, # subsample
#                             lambda_l2 = 0.1,
#                             bagging_freq = 5,
#                             min_data_in_leaf= 30,
#                             min_sum_hessian_in_leaf= 10,
#                             tree_learner='serial',
#                             boost_from_average='false',
#                             device_type='gpu',
#                             gpu_use_dp=True,
                            silent=-1,
                            verbose=-1,
                            n_jobs=-1)
        
        clf.fit(X_train, y_train, eval_set=[ (X_train, y_train),(X_test, y_test )], 
#                 eval_metric= 'mse', 
#                 categorical_feature  = ['city','town','village'],
                verbose= 6000, early_stopping_rounds= 2000)
        
        y_pred = np.expm1(clf.predict(X_test, num_iteration=clf.best_iteration_))
        print('Fold {}'.format(fold_ + 1), 'Hit-Rate plus MAPE: {}'.format(score(np.expm1(y_test), y_pred)),'\n')
        print('Fold {}'.format(fold_ + 1), 'Hit-Rate {}'.format(hit_rate(np.expm1(y_test), y_pred)),'\n')
        
        if save:
            print('Saving model fold {}'.format(fold_ + 1))
            filename = './pickle/Lgb_{}.sav'.format(fold_ + 1)
            pickle.dump(clf, open(filename, 'wb'))
            print('\n')

        oof_preds[test_index] = y_pred
        sub_preds += clf.predict(sub[feats], num_iteration=clf.best_iteration_) / sss.n_splits

        fold_importance_df = pd.DataFrame()
        fold_importance_df["feature"] = feats
        fold_importance_df["importance"] = clf.feature_importances_
#         fold_importance_df["shap_values"] = abs(shap.TreeExplainer(clf).shap_values(X_test)[:,:sub[feats].shape[1]]).mean(axis=0).T
        fold_importance_df["fold"] = fold_+ 1
        feature_importance_df = pd.concat([feature_importance_df, fold_importance_df], axis=0)
        del X_train, X_test;
        gc.collect()
        
    print('Full Hit-Rate plus MAPE score: {}'.format(score(target, oof_preds),'\n'))
    output.append(sub_preds)
    submission_file_name = "submit_score_{}_{}.csv".format(score(target, oof_preds), dt_today.strftime("%m_%d"))
    submit['total_price'] = np.mean(output, axis=0)
    submit[['building_id', 'total_price']].to_csv(submission_file_name, index= False)   
    
    display_importances(feature_importance_df)
#     display_shapley_values(feature_importance_df)
    return feature_importance_df, oof_preds, sub_preds



def main(debug_Mode = False):
    with timer('0. Metrics Testing... '):
        print('Official Metrics Test Score: ',score(np.array([1000,1000,1000]), np.array([1300,1100,1050])))
        print('Same as offical Example 6667.85')
        
    with timer("1. Data Loading... "):
        
        with multiprocessing.Pool() as pool: 
            train, test, submit = pool.map(load_df, ["train", "test", "submit_test"])
            gc.collect()
            print('\n')

    with timer("2. Categorical Features Preprocessing (Not Yet)... "):
        
        from feature_cate import city_median_transform
        from feature_outlier import land_outlier_correction

        train, test = land_outlier_correction(train, test)
        train, test = city_median_transform(train, test)
        gc.collect()
        print('\n')  
    
    with timer("3. Fill NaN / Reconstruct NaN... "):
        print('\n')
        
    with timer("4. Cluster Target Encoding & Checking Performance... "):
        from cluster_target_encoder import cluster_target_encoder
        train, test = kmeans_target_encoder(train, test)
        gc.collect()
        print('\n')
    
    with timer("5. Feature Engineering... "):
        from feature_num import feature_engineer
        from attr_correction import land_outlier_correction, parking_rulebase
        train, test = parking_rulebase(train, test)
        train, test = land_outlier_correction(train, test)
        train, test = lfeature_engineer(train, test)
        
        gc.collect()
        print('\n')        
        
    with timer("6. Modeling... "):
        feature_importance_df, oof_preds, sub_preds = model(train, test, folds)
        
##################    Global Variables    ################
folds = 10
target = 'total_price'
# 預測目標的欄位名稱，（自訂，吃字串）


##################       deBugging        ################

debug_Mode = 1
# Debug模式，在 main function 裡面。
# True: 加速測試模式，如果要改函數架構，請設定成True，加速測試時間。
# False: 全面開發模式（預設）
num_rows = 5000 if debug_Mode else None    
    
    
##################       LightGBM Hyper    ###############

lgb_params = {
            'n_josb':-1,
            'n_estimators':100000,
            'learning_rate':0.01,
            'num_leaves':150,
            'feature_fraction': 0.5,
            'bagging_fraction': 0.8,
            "bagging_freq": 5,
            #"min_data_in_leaf": 30,
            #"min_sum_hessian_in_leaf": 10,
            #"tree_learner": "serial",
            #"boost_from_average": "false",
            'silent':-1,
            'verbose':-1 }

if __name__ == "__main__":
    with timer("Let's Go Cathay Lab :-) "):
        main(debug_Mode=True)