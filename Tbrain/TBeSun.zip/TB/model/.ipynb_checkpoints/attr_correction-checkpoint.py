import pandas as pd
import numpy as np
from sklearn.model_selection import RandomizedSearchCV
from sklearn.linear_model import BayesianRidge
    #train.drop([9552], inplace=True)    
    #train = train[train['land_area']!=0]

def land_outlier_correction(train, test):
    
    train.loc[(train['land_area']==0)&(train['XIV_10000']==14502)
              &(train['building_complete_dt']==8190),
              'land_area']=9.642834
    train.loc[(train['land_area']==0)&(train['building_complete_dt']==10228),
              'land_area'] = 44.889814
    train.loc[(train['land_area']==0)&(train['building_complete_dt']==11020)&
              (train['village']==1888),
              'land_area'] = 13.106
    train.loc[(train['land_area']==0)&(train['lon']==119.32)&(train['lat']==-37.7)&
              (train['building_complete_dt']==11416),
              'land_area']= 2.222

    test.loc[(test['land_area']==0)&(test['XIV_5000']==11882)&
             (test['total_floor']==10),
             'land_area']= 2.222

    test.loc[(test['land_area']==0)&(test['lon']==119.37)&(test['lat']==-37.66)&
         (test['building_complete_dt']==6606),
             'land_area']= 2.222

    test.loc[(test['land_area']==0)&(test['lon']==119.32)&
             (test['lat']==-37.72),
             'land_area'] = 13.106
    
    for i in combine.columns:
        combine[i].replace([np.inf, -np.inf], np.nan, inplace=True)
    cols = combine.columns[~combine.isna().any()].tolist()
    
    cols = list(combine[cols].select_dtypes(include=[np.number]).columns)
    
    try:
        nan_cols.remove('land_area')
    except:pass
    y = combine[combine['land_area']!=0]['land_area']
    model = BayesianRidge(normalize=True)
    model.fit(combine[combine['land_area']!=0][cols], y)

    result = model.predict(combine[combine['land_area']==0][cols])
    combine.loc[combine['land_area']==0,'land_area'] = result

    train = combine[combine['total_price'].notnull()]
    test = combine[combine['total_price'].isnull()]
    del combine; gc.collect()
    
    return train, test
    

def parking_rulebase(train, test):
    combine = pd.concat([train, test])
    del train, test;
    assert combine[combine['parking_way']==2][['parking_area']].shape[0] == combine[(combine['parking_way']==2)&(combine['parking_area'].isnull())].shape[0] 
    assert combine[combine['parking_way']==2][['parking_price']].shape[0] == combine[(combine['parking_way']==2)&(combine['parking_price'].isnull())].shape[0] 

    combine.loc[combine['parking_way']==2,'parking_area'] = 0
    combine.loc[combine['parking_way']==2,'parking_price'] = 0
    # parking price 請三思去處理
    
    train = combine[combine['total_price'].notnull()]
    test = combine[combine['total_price'].isnull()]
    del combine;
    return train, test

def parking_way_relabel(train, test):
    re_map = { 2:0, 1:1, 1:2}

    train['parking_way'] = train['parking_way'].map(re_map)
    test['parking_way'] = test['parking_way'].map(re_map)
    return train, test


def median_income_rulebase(train, test):
    """
    概念：
    
    1.同一個經緯度之下，排除NaN的，看有幾筆相同經緯度，太多就看std，極少（自己定義）
    2.如果差異「低於」自己定義的臨界值，賦予周遭的median / mean 數值
    
    可以tune的地方是有以上兩處
    """
    combine = pd.concat([train, test])
    del train, test;
    gc.collect()
    print('Initial # of Median income NaN {}'.format(combine[combine['village_income_median'].isnull()].shape))
    collection = list(combine[combine['village_income_median'].isnull()]['lonlat'].unique())
    for i in collection:
        if combine[combine['lonlat']==i]['village'].nunique()>2: ## Tune 1

            if combine[combine['lonlat']==i]['village_income_median'].std() <=30: # Tune 2
                combine.loc[(combine['village_income_median'].isnull())&(combine['lonlat']==i), 
                            'village_income_median'] = combine[combine['lonlat']==i]['village_income_median'].mean()
    
    print('Processed # of Median income NaN {}'.format(combine[combine['village_income_median'].isnull()].shape))

    train = combine[combine['total_price'].notnull()]
    test = combine[combine['total_price'].isnull()]
    del combine;
    return train, test


def town_village_issue(train, test):
    """
    串接city+town 取代 town
    串接 city+town+village 取代 village
    """
    combine = pd.concat([train, test])
    combine['town'] = combine['city'].astype(str) + '_' + combine['town'].astype(str)
    combine['village'] = combine['city'].astype(str) + '_' + combine['town'].astype(str)+ '_' + combine['village'].astype(str)
    
    train = combine[combine['total_price'].notnull()]
    train = combine[combine['total_price'].isnull()]
    del combine; gc.collect()
    
    return train, test