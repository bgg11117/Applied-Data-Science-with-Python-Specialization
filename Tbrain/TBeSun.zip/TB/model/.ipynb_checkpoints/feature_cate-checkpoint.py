import pandas as pd
import numpy as np

def city_median_transform(train, test):
    
    city_map = {3:'Keelung',13:'Taipei', 7:'NewTaipei', 10:'TaoYuan',
                9:'Hsinchu', 17:'Miaoli', 12:'Taichung', 6:'Changhua', 
                14:'Tainan', 21:'Kaohsiung', 5:'Pingtung'}
    
    median_price = {'Changhua': 1.0916621111046303, 'Hsinchu': 2.958601083338409,
     'Kaohsiung': 0.9680884880105681,'Keelung': 0.33401788120349857,
     'Miaoli': 0.9681243091859688, 'NewTaipei': 4.275976993446305,
     'Pingtung': 2.309791387556655e-08,'Taichung': 2.334133478716725,
     'Tainan': 1.2064160686508798,'Taipei': 11.516340035671604,
     'TaoYuan': 1.6873002093074245}
    
    train['city'] = train['city'].map(city_map)
    test['city'] = test['city'].map(city_map)
    
    train['city'] = train['city'].map(median_price)
    test['city'] = test['city'].map(median_price)
    
    return train, test


def create_doc(train, test, cate = ['village_income_median','town','village','CityTown']):   
    """
    Create DOC，要丟給 W2Vec 去train
    """
    train['txn_yr'] = np.round(train['txn_dt']/365, 1)
    test['txn_yr'] = np.round(test['txn_dt']/365, 1)
    
    cols_to_use = ['txn_yr'] +  cate 
    trn = train[cols_to_use]
    sub = test[cols_to_use]
    for i in cate:
        trn[i] = trn[i].astype(str)
        sub[i] = sub[i].astype(str)
    doc = pd.concat([trn, sub], axis=0)
    doc.sort_values('txn_yr', inplace=True)
    del trn, sub;gc.collect()
    sentences = []

    for i in doc['txn_yr'].unique():
        d = doc[cols_to_use[1:]].loc[(doc['txn_yr'] == i) ]\
                                    .drop_duplicates().as_matrix().flatten().tolist()
        if d: 
            sentences.append(d)

    del doc, train['txn_yr'], test['txn_yr']; gc.collect()
    return train, test, sentences

train, test, sentences = create_doc(train, test, cate = ['village_income_median','town','village','CityTown'])

def w2vec(train, test, sentences, cate = 'CityTown'):
    combine = pd.concat([train, test])
    del train, test;gc.collect()
    model = Word2Vec(sentences, size=10, window=30, min_count=1, sample=0, negative = 7,
                     workers=multiprocessing.cpu_count(), iter=30)

    w2v_df = combine[cate].astype('object').apply(lambda x: pd.Series(model.wv[x]))
    w2v_df = w2v_df.add_prefix('w2v' + cate + '_')
    combine = pd.concat([combine, w2v_df], axis=1)
    train = combine[combine['total_price'].notnull()]
    test = combine[combine['total_price'].isnull()]
    del combine, w2v_df; 
    del train[cate], test[cate];
    gc.collect()
    return train, test


