## eda_1
   - 利用「city」「lon」「lat」建構出台灣樣貌。
    - 座標轉換是沒意義的。
    - 確認 train / test 的分佈一致性。
    - 有些「city」的價格轉換後，依然不是類Gaussian，有skew。
    - Baseline 成績約5390 +- 50
    - 建物面積, 土地面積, 交易日期 為重要特徵 (Tree 所看到)

## eda_2
   - 使用city lon lat 對應正確的city real name
    - 座標轉換是「有」意義的，豐宇幫忙。（否決EDA1的結論）
    - order 9的房價，出現在，台北，新北，台中，高雄。
    - 台北 median 房價order 7 其餘都是 order 6
    - var/std 在台北最大
    - np.log1p 高雄，新北，彰化 房價，右邊有小高斯分佈
    - np.log1p 苗栗，雙高斯重疊
    - np.log1p 新竹，三高斯重疊
    
   - lgb MAE num_leaves = 31 特徵重要性：
        1. txn_dt交易日期
        2. building_area
        3. building_complete_dt 建物完成日期
        4. land_area
        5. XII_min
        6. txn_floor 交易樓層
        7. I_min ~ XIV_min
    
   - SHAP MAE  num_leaves = 31 
        1. building_area
        2. XIII_10000
        3. land_area
        4. txn_floor
        5. txn_dt
        6. jobschool_rate
        7. village_income_median
     
    - lolat TARGET Encoding plus 100

**再度確認median房價order**，建議台北要獨立出來train.

## eda_3
   - Coord transform Cluster work better (imbalanced) but CV not.
   - 使用Cluster 當作新目標，重要特徵還就是地理座標。
       - 所以重新定義，有意義的類別，不受地理位置干擾。
   - 使用 village 當作新的類別

**以確認，「使用ＶＳ不使用」Cluster TE 使用成績比較好**
**DBSCAN or HCA ?? **

## eda_4
   - Hit Rate Error Analysis
    - city, town, village 放入 lgb categorical_features  **會變糟糕**
    - city, town, village transform to meaningful vectors
    - New Taipei City Hit Rate 出包最多～
    - 1 個 village 對應多個 city
    - 1 個 village 對應多個 town
    - 1 個 town 對應多個 city
    - 豐宇提出concate 處理這問題，以及以下
- continious data cleaning [ArXiv](http://www.cs.toronto.edu/~mvolkovs/icde14_data_cleaning.pdf)

**已確認，上述是地名重複，驗法方式 使用大量抽樣算距離**

# eda_5 Part I
   - [x] 修正concat問題
     
   - What did not work.
     
        1. concat city town village using cluster target encoding 無法有效區分出
        2. citytownvillage target encoding (sklearn contrib)
             try to apply regularization
      
   - What I found.
     
        - Q: 需要買停車位的縣市，應該是大城市(cnt/%)
            - 新北，台北，桃園，台中，高雄，新竹 (cnt)
            - 新北，桃園，台北，新竹，台中，基隆 (%)
            
        - Q: No need 買停車位的縣市，應該是small城市 (cnt/%)
            - 新北，台北，桃園，台中，高雄 (cnt)
            - 苗栗，屏東，台南，高雄，彰化 (%)
            
        - Hypothesis: 停車方式2 = 路邊停車？
            - 停車方式2，高到低：屏東，苗栗，彰化，台南 (90% +)
            

**停車方式2 怎應用？**

```python
D = {
3:'Keelung',13:'Taipei', 7:'NewTaipei', 10:'TaoYuan', 9:'Hsinchu', 
17:'Miaoli', 12:'Taichung', 6:'Changhua', 14:'Tainan', 21:'Kaohsiung', 
5:'Pingtung'}

Temp = {}
Ans = {}
for i in combine['city'].unique():
    Temp[i] = combine[(combine['parking_area'].isnull())&(combine['city']==i)].shape[0]    
    Temp[i]/= combine[combine['city']==i].shape[0]
    Ans[D[i]] = Temp[i]

sorted(Ans.items(), key=operator.itemgetter(1))

```

# eda_5 Part II
   - Part I 延伸出 floor 1 是獨棟還是公寓一樓。

       1. 雙北，一樓中位數都高於，公寓
       2. 最低價都是一樓最高
       3. 最高價除了「台南，屏東」，其餘都是 「公寓」屌打「一樓」
           - 一樓都是屬於郊區？？？？
           - quantile(0.7) 可以看出房價差異大 台中台南
           
```python
for i in train['city'].unique(): 
    print(D[i],train[(train['txn_floor']==1)&(train['city']==i)]['total_price'].quantile(0.9))
    print(D[i],train[(train['txn_floor']!=1)&(train['city']==i)]['total_price'].quantile(0.9),'\n')
```

### 中位數 groupby floor
	1 台北越高樓越貴（合理）(13樓有 存在精華區)
	2 新北最高樓有 outlier (28層樓 窮人區？)
	3 台中第二高樓有 outlier (27層樓 鬧鬼)
	4 苗栗第二高樓有 outlier (9 鬧鬼？)
	5 屏東符合

### 最高價 groupby floor
    1 台北 一樓最貴（獨棟？）
    2 新北，大致上一樓很貴，有某些公寓更高價（做地段鎖定）
    3 桃園一樓最貴
    4 新竹 1 2 3  樓 高其他一個 order
    5 台中 一樓最貴（獨棟？）(做地段鎖定)
    6 新竹，1-3樓 最貴 差一個 order (why)
    7 * 台南越高的越便宜 ＠＠
    8 高雄穩定，獨棟最貴
    9 Pingtung 一樓最貴

**Conclusion:**
    1. 依據city中位數價錢去重新定義 label

## 留下的問題：
- 一樓的問題待處理 

# eda_5 Part III

## Village Income Median Recovery
- [X] 檢視直接補值可能性
- [X] 處理duplicat問題，1 village map multi town city
- [X] 檢視median income 與 何者最大關聯
    - LGB __txn_dt__, area_ratio, village, XII_Min, area_diff, VIII_Min, building_complete_dt
    
### objective function
   - [kaggle fair loss](https://www.kaggle.com/c/allstate-claims-severity/discussion/24520)

### Median income
- [X] 檢視直接補值可能性
    - city + town + village **沒有** 關聯性直接補值可能
    

**Conclusion:** 1 village map multi city/town，是同地名(eda_4)，無法處理。
    
# eda_6
### 日期的探索
- [x] 交易日研究
	- 官方取用「連續七年」的資料。
      
- [x] 成交研究

### 單位面積價位
- What I Found
	- 1. 有outlier，land_area ==0
		- [x] 手動修復
		- [x] 硬比對
		- [x] 處理 Bayesian 會出現infinite 問題～

## 留下的問題：
    1. Bayesian 的參數處理

**Conclusion:** 官方給七年資料，有提早購屋的情況，寫出recover 模組            
            
# eda_7

## 驗證，台北，非台北 分開train的CV 會很高。
- Taipei
		- 只針對台北cluster TE
		- 5918.873, folds = 7
- Exclude Taipei
		- 5762.871, folds = 10 
		- 失去台北，整體好差～ __WHY__ ?

- [x] 測試Cluster Median Target Encoding

        - Performance  __worse__ than mean

## 留下的問題：
    1. 失去台北，整體好差～ __WHY__ ?


# eda_8

## Parking Recovery (基於 eda_5)

- [x] Parking_way = 2 的 Parking_area 皆為 `NaN`
        - 路邊停車 [ eda_5 Part I ]
```python
assert train[train['parking_way']==2][['parking_area']].shape[0] == train[(train['parking_way']==2)&(train['parking_area'].isnull())].shape[0] 
        
```
## Parking_way, Parking_area, Parking_price 修復
- [x] Parking way = 2, impute Parking_area = 0
    - Baseline 提升到 **5871.873**
    - 只有 **一個** Fold 低於0.58
- [x] Parking way =2, impute Parking_price = 0
    - Baseline 下降一些 **5871.873**
        - [x] 先把Fold index 撈出來看縣市
            - 該Fold差異性最大的欄位叫做「town」
            - Town 重複問題要修復

- [ ] 與交易日期是否有關？
- [ ] 修正parking問題
	- [ ] 使用貝氏定理 (要等 NaN 修復完才能做)
	- [ ] 統計法

## village_income_median recovery
- **remind:** 只有七年的數據，假設是近期。
	- [x] 薪資不會隨房價異動太大。 
		- 關聯性0.44，低。
	- [x] 最大相關特徵檢視
		- 1. 交易日
		- 2. 建物面積
		- 3. village (廢話)
		- 4. 屋齡
		- 5. Updated eda_5 Part III
	- [x] 使用經緯度去查詢相同的lonlat，看其他的 village income median 是否差不多
        - 有跨town問題
        - [x] 驗證薪資七年內浮動
        - CV 「略不好」，但可以調整 `std` 決定
    - [x] drop `VIM worse the score`
    - [ ] Moving Average on `VIM`
    - [ ] 使用 `KNN` 去補 village_income_median


## 留下的問題：
- 1. 重新編碼 Town / village

**Conclusion:** 
- 1. `village_income_median` 與 房價，相關性只有 0.44 (0.75+ better)

- 2. VIM 只有「新竹」七年間，變動劇烈下降，其餘都沒變（薪資沒調）
- 3. VIM 跟 TP 相關性
	- Hsinchu 0.6840542171880224   
	- TaoYuan -0.6869879978116139
	- Kaohsiung -0.48587340565711784
	- NewTaipei 0.29220999227867184
	- Taichung 0.1362150551754448
	- Miaoli -0.20781607263306837
	- Changhua -0.22675777250947332
	- Pingtung 0.20471796667982148
	- Taipei 0.1344224339183379
	- Tainan 0.0026884224079945
	- Keelung 0.043792577766696296
  
- 4. village = 1705，很大可能是新竹市東區關新里，因為最高的village income median

- 5. 基於Baseline 0.5871 某個 Fold 低於0.58，來到0.577，檢視該 **Fold** 差異性最大的欄位叫做「town」
    - 可以說「town」會導致學錯，已知原因，不同city下有，__同名town__

- 6. Base on 5, 做了一個 function `Tell_me_Why` 基於metric performance，去比對每個fold 欄位統計上的差異 

- 7. Parking way = 2, 補 Parking_area = 0, Baseline 提升到 **5871.873**
- 7.1 依樣畫葫蘆，補 Parking_price = 0 ， **CV** 略降低
    - SHAP 角度Parking_price 算是重要，所以不應該只是簡單的修補。

# eda_9



## 檢視七年時間的，房價變化的趨勢性

**台北房價交易日逐年遞增**

- 重新編碼 town / village

    - [ ] town 加入Prefix Label by house price (normalize/ non-normalize)
    - [ ] village 加入Prefix
    
- [ ] 房價與交易日期的關聯度
- [ ] 房價與完工日期的關聯度





# EDA 累積待處理的問題
- [ ] DBSCAN or HCA 
- [ ] 一樓的問題待處理 
- [ ] 排除台北，整體performance 好差～ why
- [ ] 修復工程之「參數驗證」，怎判斷合理性
- [ ] 能否重新編碼 town / village
    - [ ] Try 一對多，加入Prefix


# Score 
- Clustering TE __5830__
- 類別 1e4-1e3 diff __5862__


​    